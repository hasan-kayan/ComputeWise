from .wifi_sec import (
    check_wpa3_support,
    check_wifi_encryption,
    detect_weak_encryption,
    save_security_protocol_history,
    get_security_protocol_history
)
